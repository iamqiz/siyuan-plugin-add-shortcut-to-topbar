/*!
 * MIT License
 *
 * Copyright (c) 2024 iamqiz
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */(()=>{"use strict";var b={};b.d=(e,t)=>{for(var o in t)b.o(t,o)&&!b.o(e,o)&&Object.defineProperty(e,o,{enumerable:!0,get:t[o]})},b.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),b.r=e=>{typeof Symbol<"u"&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var h={};b.r(h),b.d(h,{default:()=>K});const f=require("siyuan");var P=Object.defineProperty,T=Object.defineProperties,C=Object.getOwnPropertyDescriptors,B=Object.getOwnPropertySymbols,x=Object.prototype.hasOwnProperty,q=Object.prototype.propertyIsEnumerable,S=(e,t,o)=>t in e?P(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o,E=(e,t)=>{for(var o in t||(t={}))x.call(t,o)&&S(e,o,t[o]);if(B)for(var o of B(t))q.call(t,o)&&S(e,o,t[o]);return e},_=(e,t)=>T(e,C(t));const F="keylistConfig",I="custom_tab",N="dock_tab",Y=e=>new Promise(t=>setTimeout(t,e));class K extends f.Plugin{onload(){console.log("--- onload:"+this.name);const t=(0,f.getFrontend)();this.isMobile=t==="mobile"||t==="browser-mobile",this.addIcons(`<symbol id="iconFace" viewBox="0 0 32 32">
<path d="M13.667 17.333c0 0.92-0.747 1.667-1.667 1.667s-1.667-0.747-1.667-1.667 0.747-1.667 1.667-1.667 1.667 0.747 1.667 1.667zM20 15.667c-0.92 0-1.667 0.747-1.667 1.667s0.747 1.667 1.667 1.667 1.667-0.747 1.667-1.667-0.747-1.667-1.667-1.667zM29.333 16c0 7.36-5.973 13.333-13.333 13.333s-13.333-5.973-13.333-13.333 5.973-13.333 13.333-13.333 13.333 5.973 13.333 13.333zM14.213 5.493c1.867 3.093 5.253 5.173 9.12 5.173 0.613 0 1.213-0.067 1.787-0.16-1.867-3.093-5.253-5.173-9.12-5.173-0.613 0-1.213 0.067-1.787 0.16zM5.893 12.627c2.28-1.293 4.040-3.4 4.88-5.92-2.28 1.293-4.040 3.4-4.88 5.92zM26.667 16c0-1.040-0.16-2.040-0.44-2.987-0.933 0.2-1.893 0.32-2.893 0.32-4.173 0-7.893-1.92-10.347-4.92-1.4 3.413-4.187 6.093-7.653 7.4 0.013 0.053 0 0.12 0 0.187 0 5.88 4.787 10.667 10.667 10.667s10.667-4.787 10.667-10.667z"></path>
</symbol>
<symbol id="iconSaving" viewBox="0 0 32 32">
<path d="M20 13.333c0-0.733 0.6-1.333 1.333-1.333s1.333 0.6 1.333 1.333c0 0.733-0.6 1.333-1.333 1.333s-1.333-0.6-1.333-1.333zM10.667 12h6.667v-2.667h-6.667v2.667zM29.333 10v9.293l-3.76 1.253-2.24 7.453h-7.333v-2.667h-2.667v2.667h-7.333c0 0-3.333-11.28-3.333-15.333s3.28-7.333 7.333-7.333h6.667c1.213-1.613 3.147-2.667 5.333-2.667 1.107 0 2 0.893 2 2 0 0.28-0.053 0.533-0.16 0.773-0.187 0.453-0.347 0.973-0.427 1.533l3.027 3.027h2.893zM26.667 12.667h-1.333l-4.667-4.667c0-0.867 0.12-1.72 0.347-2.547-1.293 0.333-2.347 1.293-2.787 2.547h-8.227c-2.573 0-4.667 2.093-4.667 4.667 0 2.507 1.627 8.867 2.68 12.667h2.653v-2.667h8v2.667h2.68l2.067-6.867 3.253-1.093v-4.707z"></path>
</symbol>`),this.addTopBar({icon:"iconFace",title:"\u6DFB\u52A0\u5FEB\u6377\u952E\u5230\u5DE5\u5177\u680F-\u914D\u7F6E",position:"right",callback:()=>{this.openSetting()}}),this.loadData(F).then(o=>{if(console.log(`${this.name} \u52A0\u8F7D\u914D\u7F6E:${o.length}\u4E2A`),o instanceof Array)for(let i=0;i<o.length;i++){let l=o[i];console.log(`${i} ${l.enable?"\u542F\u7528":"\u7981\u7528"} ${l.shortcut}`),l.enable&&this.addTopBar({icon:l.icon,title:l.shortcut+`
`+l.title,position:l.position,callback:()=>{console.log("\u70B9\u51FB\u4E86:\u5DE5\u5177\u680F 3"),console.log(l.shortcut),console.log(l.keyinfo);let r=JSON.parse(l.keyinfo),a=document.querySelector(".layout__center [data-type='wnd'].layout__wnd--active > .layout-tab-container > div:not(.fn__none) .protyle-wysiwyg");if(console.log("editor:"),console.log(a),a){let c={ctrlKey:!1,shiftKey:!1,altKey:!1,metaKey:!1,key:"Escape",code:"Escape",keyCode:27};window.dispatchEvent(new KeyboardEvent("keydown",_(E({},c),{bubbles:!0}))),setTimeout(()=>{a.dispatchEvent(new KeyboardEvent("keydown",_(E({},r),{bubbles:!0})))},100)}else document.body.dispatchEvent(new KeyboardEvent("keydown",_(E({},r),{bubbles:!0})))}})}}),console.log(this.i18n.helloPlugin+this.name)}onLayoutReady(){console.log("----onLayoutReady:"+this.name),console.log(`frontend: ${(0,f.getFrontend)()}; backend: ${(0,f.getBackend)()}`)}onunload(){console.log(this.i18n.byePlugin)}uninstall(){console.log("uninstall "+this.name)}openSetting(){const t=new f.Dialog({title:this.name,height:"90vh",content:`<div class="b3-dialog__content">
<!--<button id="testbtn">\u70B9\u51FB</button>-->
</div>
<div class="b3-dialog__action">
    <button class="b3-button b3-button--cancel">${this.i18n.cancel}</button><div class="fn__space"></div>
<!--    <button class="b3-button b3-button&#45;&#45;text">${this.i18n.save}</button>-->
</div>`,width:this.isMobile?"92vw":"820px"});t.element.querySelectorAll(".b3-button")[0].addEventListener("click",()=>{t.destroy()});let i=t.element.querySelector(".b3-dialog__content"),l=document.createElement("div");i.appendChild(l),l.className="fn__block",l.innerHTML=`
<div style="padding-bottom: 10px">
<h4>\u914D\u7F6E\u8BF4\u660E</h4>
<b>\u65B0\u5EFA</b>: \u589E\u52A0\u4E00\u4E2A\u5DE5\u5177\u680F\u56FE\u6807\u914D\u7F6E<br>
<b>\u52A0\u8F7D\u56FE\u6807</b>: \u663E\u793A\u601D\u6E90\u6240\u6709\u56FE\u6807,\u7136\u540E\u4F60\u53EF\u4EE5\u590D\u5236\u56FE\u6807\u540D\u79F0\u586B\u5165\u5230\u56FE\u6807\u8F93\u5165\u6846<br>
<b>\u4FDD\u5B58\u914D\u7F6E</b>: \u4FDD\u5B58\u6240\u6709\u914D\u7F6E,\u65E0\u5FEB\u6377\u952E\u7684\u914D\u7F6E\u4F1A\u88AB\u5FFD\u7565<br>
<b>\u5237\u65B0\u9875\u9762</b>: \u5237\u65B0\u9875\u9762\u4F7F\u914D\u7F6E\u751F\u6548
</div>

<button data-type="new">\u65B0\u5EFA</button>
<button data-type="load-icons">\u52A0\u8F7D\u56FE\u6807</button>
<button data-type="save">\u4FDD\u5B58\u914D\u7F6E</button>
<button data-type="reload">\u5237\u65B0\u9875\u9762</button>
<span data-type="msg"></span>
`;let r=l.querySelector('[data-type="msg"]'),a=m('<div data-type="keylist" class="plugin-add-shortcut-to-topbar__block"></div>');l.appendChild(a);let c=m('<div data-type="iconlist" class="plugin-add-shortcut-to-topbar__fn_clear "></div>');l.appendChild(c),c.addEventListener("click",n=>{let u=n.target;console.log("\u70B9\u51FB\u56FE\u6807:"),console.log(u),u.dataset.type=="iconName"&&navigator.clipboard.writeText(u.textContent.trim()).then(()=>{console.log("\u590D\u5236\u6210\u529F"),u.setAttribute("data-content","\u5DF2\u590D\u5236"),setTimeout(()=>{u.setAttribute("data-content","\u70B9\u51FB\u590D\u5236")},1500)},s=>{console.error("Async: Could not copy text: ",s)})});let g=this.data[F];if(console.log("\u4FDD\u5B58\u7684\u914D\u7F6E:"),console.log(g),g)for(let n=0;n<g.length;n++){let u=g[n],s=w.call(this,{enable:u.enable,name:u.title,keystr:u.shortcut,icon:u.icon,position:u.position,keyinfo:u.keyinfo});a.appendChild(s)}l.querySelector('[data-type="new"]').addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),console.log("\u65B0\u5EFA:"),console.log(n.target);let u=w.call(this,{});a.appendChild(u)}),l.querySelector('[data-type="save"]').addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),r.innerHTML="",console.log("\u4FDD\u5B58:"),console.log(n.target);let u=[],s=0,d;for(let p=0;p<a.childElementCount;p++){d=a.childNodes[p];let y=L(d);y&&u.push(y)}console.log("\u4FDD\u5B58\u914D\u7F6E:"),console.log(u),this.saveData(F,u),setTimeout(()=>{r.innerHTML=`\u5DF2\u4FDD\u5B58${u.length}\u4E2A\u5DE5\u5177\u680F\u56FE\u6807`},200)}),l.querySelector('[data-type="load-icons"]').addEventListener("click",n=>{c.innerHTML="",r.innerHTML="",c.setAttribute("hidden","");let u=document.querySelectorAll("symbol"),s,d,p=0;for(let y=0;y<u.length;y++)if(s=u[y],d=s.getAttribute("id"),d){p++;let D=`<div><svg class="plugin-add-shortcut-to-topbar__svg"><use xlink:href="#${d}"></use></svg>
<div class="hover-text" data-content="\u70B9\u51FB\u590D\u5236" data-type="iconName">${d}</div>
</div>`,k=m(D);c.appendChild(k)}setTimeout(()=>{c.removeAttribute("hidden"),r.innerHTML=`\u5DF2\u52A0\u8F7D${p}\u4E2A\u56FE\u6807`},200)}),l.querySelector('[data-type="reload"]').addEventListener("click",n=>{window.location.reload()})}}function m(e,t=!0){if(e=t?e.trim():e,!e)return null;const o=document.createElement("template");o.innerHTML=e;const i=o.content.children;return i.length===1?i[0]:i}function w({name:e="",keystr:t="",enable:o=!0,icon:i="iconGithub",position:l="right",keyinfo:r=""}){let a=document.createElement("div");a.innerHTML=`\u6807\u9898 <input type="text" data-type="title" value="${e}" placeholder="\u63D0\u793A\u8BED,\u53EF\u9009" spellcheck="false" class="plugin-add-shortcut-to-topbar__titleInput"/>
\u5FEB\u6377\u952E <input type="text" data-type="shortcut" value="${t}" placeholder="\u6309\u4E0B\u5FEB\u6377\u952E,\u5FC5\u586B" spellcheck="false" class="plugin-add-shortcut-to-topbar__shortcutInput" size="15" />
\u56FE\u6807 <input type="text" data-type="icon" value="${i}" spellcheck="false" class="plugin-add-shortcut-to-topbar__iconInput"/>
<svg class="b3-menu__icon">
<use xlink:href="#${i}"></use>
</svg>\u4F4D\u7F6E
<select data-type="position">
<option value="right">right</option>
<option value="left">left</option>
</select>
\u542F\u7528 <input type="checkbox" data-type="enable" ${o?"checked":""} />
<button>\u5220\u9664</button>`,a.className="fn__flex-1",a.querySelector("button").addEventListener("click",n=>{let s=n.target.parentElement;console.log("p:"),console.log(s),setTimeout(()=>{s?.remove()},100)});let c=a.querySelector('[data-type="position"]');c.value=l;let g=a.querySelector('[data-type="shortcut"]');return g.dataset.keyinfo=r,g.addEventListener("keydown",n=>{n.stopPropagation(),n.preventDefault();let u=n.target;const s=$(n);let{ctrlKey:d,shiftKey:p,altKey:y,metaKey:D,key:k,code:z,keyCode:H}=n,A={ctrlKey:d,shiftKey:p,altKey:y,metaKey:D,key:k,code:z,keyCode:H};console.log("keyinfo:"),console.log(A);let M=JSON.stringify(A);console.log(M),u.dataset.keyinfo=M,setTimeout(()=>{let O=j(s);u.value=O=="Backspace"?"":O})}),a.querySelector('[data-type="icon"]').addEventListener("change",n=>{n.stopPropagation(),n.preventDefault();let u=n.target;console.log("\u56FE\u6807id\u4E3A:"+u.value),a.querySelector("use").setAttribute("xlink:href",`#${u.value}`)}),a}function L(e){let t={},o=e.querySelector('[data-type="shortcut"]');if(!o.value)return null;t.shortcut=o.value,t.keyinfo=o.dataset.keyinfo||"";let i=e.querySelector('[data-type="title"]');t.title=i.value;let l=e.querySelector('[data-type="icon"]');t.icon=l.value;let r=e.querySelector('[data-type="position"]');t.position=r.value;let a=e.querySelector('[data-type="enable"]');return t.enable=a.checked,t}const v=()=>navigator.platform.toUpperCase().indexOf("MAC")>-1;function $(e){let t="";return e.ctrlKey&&v()&&(t+="\u2303"),e.altKey&&(t+="\u2325"),e.shiftKey&&(t+="\u21E7"),(e.metaKey||!v()&&e.ctrlKey)&&(t+="\u2318"),e.key!=="Shift"&&e.key!=="Alt"&&e.key!=="Meta"&&e.key!=="Control"&&e.key!=="Unidentified"&&(e.keyCode===229?e.code==="Minus"?t+="-":e.code==="Semicolon"?t+=";":e.code==="Quote"?t+="'":e.code==="Comma"?t+=",":e.code==="Period"?t+=".":e.code==="Slash"&&(t+="/"):t+=f.Constants.KEYCODELIST[e.keyCode]||(e.key.length>1?e.key:e.key.toUpperCase())),t}const j=e=>{if(v())return e;const t=new Map(Object.entries({"\u2318":"Ctrl","\u2303":"Ctrl","\u21E7":"Shift","\u2325":"Alt","\u21E5":"Tab","\u232B":"Backspace","\u2326":"Delete","\u21A9":"Enter"})),o=[];(e.indexOf("\u2318")>-1||e.indexOf("\u2303")>-1)&&o.push(t.get("\u2318")),e.indexOf("\u21E7")>-1&&o.push(t.get("\u21E7")),e.indexOf("\u2325")>-1&&o.push(t.get("\u2325"));const i=e.replace(/⌘|⇧|⌥|⌃/g,"");return i&&o.push(t.get(i)||i),o.join("+")};module.exports=h})();
