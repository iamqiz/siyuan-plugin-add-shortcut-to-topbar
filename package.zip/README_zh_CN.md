# siyuan plugin  add-shortcut-to-topbar

## 功能

在工具栏(顶栏)的左右两边添加图标按钮,一个图标对应一个快捷键,点击图标即可执行对应的快捷键